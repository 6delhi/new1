const express = require("express");
const router = express.Router();
const {
  getAllStudentsWithCourses,
  getStudent,
  createStudent,
  updateStudent,
  deleteStudent,
  getCourses,
} = require("../controllers/studentController");

router.get("/", getAllStudentsWithCourses);
router.get("/courses", getCourses);
router.get("/:id", getStudent);
router.post("/", createStudent);
router.put("/:id", updateStudent);
router.delete("/:id", deleteStudent);

module.exports = router;
