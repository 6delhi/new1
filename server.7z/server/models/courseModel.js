const pool = require("../config/db");

exports.getAllCourses = async () => {
  const [rows] = await pool.promise().query("SELECT * FROM courses");
  return rows;
};
