const pool = require("../config/db");

exports.getAllStudents = async () => {
  const [rows] = await pool.promise().query(`
    SELECT s.*, c.name as course_name
    FROM students s
    JOIN courses c ON s.course_id = c.id
  `);
  return rows;
};

exports.getStudentById = async (id) => {
  const [rows] = await pool
    .promise()
    .query("SELECT * FROM students WHERE id = ?", [id]);
  return rows[0];
};

exports.createStudent = async (student) => {
  const { name, email, course_id, address, mobile, dob } = student;
  const [result] = await pool
    .promise()
    .query(
      "INSERT INTO students (name, email, course_id, address, mobile, dob) VALUES (?, ?, ?, ?, ?, ?)",
      [name, email, course_id, address, mobile, dob]
    );
  return result.insertId;
};

exports.updateStudent = async (id, student) => {
  const { name, email, course_id, address, mobile, dob } = student;
  await pool
    .promise()
    .query(
      "UPDATE students SET name = ?, email = ?, course_id = ?, address = ?, mobile = ?, dob = ? WHERE id = ?",
      [name, email, course_id, address, mobile, dob, id]
    );
};

exports.deleteStudent = async (id) => {
  await pool.promise().query("DELETE FROM students WHERE id = ?", [id]);
};
