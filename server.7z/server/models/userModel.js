const pool = require("../config/db");

// Store plain password (⚠️ not secure, only for local use)
exports.createUser = async (user) => {
  const { username, email, password } = user;
  const [result] = await pool
    .promise()
    .query("INSERT INTO login (username, email, password) VALUES (?, ?, ?)", [
      username,
      email,
      password,
    ]);
  return result.insertId;
};

exports.findUserByUsername = async (username) => {
  const [rows] = await pool
    .promise()
    .query("SELECT * FROM login WHERE username = ?", [username]);
  return rows[0];
};
